  <footer class="main-footer text-left no-print">
    <strong>Copyright &copy; 2017 <a href="https://watanict.com">Watan ICT</a>
  </footer>